# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 21:42:28 2021

@author: eamidsx
"""

from setuptools import setup

setup(name = "sample_package",
      version = "0.1",
      author="dsamit",
      packages = ["sample_package"])