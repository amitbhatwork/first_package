# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 21:42:28 2021

@author: eamidsx
"""

from setuptools import setup,find_packages

setup(name = "sample_package",
      version = "0.2",
      author="dsamit",
      packages = find_packages())