# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 21:40:49 2021

@author: eamidsx
"""

def function2():
    print("Getting function2")