# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 21:39:22 2021

@author: eamidsx
"""

def function1():
    print("Getting function1")